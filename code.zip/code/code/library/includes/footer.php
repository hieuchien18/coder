   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div style="text-align: center;" class="col-md-12">
                   &copy; Nhóm 7<h3>Đại Học CNTT & Truyền Thông Thái Nguyên</h3>
                </div>

            </div>
        </div>
    </section>